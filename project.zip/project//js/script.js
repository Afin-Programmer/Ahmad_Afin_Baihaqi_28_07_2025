 document.getElementById("LoginForm").addEventListener('submit',function(event) {
        event.preventDefault();
        
        var Username = document.getElementById('Username').value;
        var password = document.getElementById('password').value;
        var errorMessage = document.getElementById('error-message');
        
        if (Username === '' || password === ''){
            errorMessage.textContent = 'gak boleh kosong dek';
        
        } else if (Username !== 'afin' || password !=='123') {
            errorMessage.textContent = 'username atau password beda coba masukan lagi';
        } else {
            errorMessage.textContent = ''
            alert('login berhasil');
        }
        
      } );